<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mod_provinsi extends CI_Model {


	function tanggal(){
		
	}
	

}

/* End of file Mod_provinsi.php */
/* Location: ./application/models/Mod_provinsi.php */